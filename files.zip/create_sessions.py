#!/usr/bin/env python3
"""
create_sessions.py
Create/encrypt session strings for multiple Telegram user accounts using Telethon.

Input: phones.csv  (columns: phone,api_id,api_hash,proxy_optional)
Output: sessions.csv (columns: phone,enc_session_string,created_at,error)

Usage:
  - pip install telethon cryptography
  - export TELE_SESSION_KEY="$(python -c 'from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())')"
  - Fill phones.csv
  - python create_sessions.py
"""
import csv
import os
import sys
import time
from datetime import datetime
from getpass import getpass

from cryptography.fernet import Fernet
from telethon import TelegramClient
from telethon.sessions import StringSession

INPUT_CSV = "phones.csv"
OUTPUT_CSV = "sessions.csv"
# Number of seconds to wait between accounts to reduce rate-limits.
DELAY_BETWEEN = 5

def load_key():
    key = os.getenv("TELE_SESSION_KEY")
    if not key:
        print("ERROR: TELE_SESSION_KEY environment variable not set.")
        print("Generate one with:\n"
              "  python -c \"from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())\"")
        sys.exit(1)
    try:
        return Fernet(key.encode())
    except Exception as e:
        print("ERROR: invalid TELE_SESSION_KEY:", e)
        sys.exit(1)

def ensure_input_csv():
    if not os.path.exists(INPUT_CSV):
        print(f"ERROR: {INPUT_CSV} not found. Create it with header: phone,api_id,api_hash,proxy")
        sys.exit(1)

def read_phones():
    rows = []
    with open(INPUT_CSV, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for r in reader:
            phone = r.get('phone') or r.get('phone_number')
            api_id = r.get('api_id')
            api_hash = r.get('api_hash')
            proxy = r.get('proxy') or ""
            if not phone or not api_id or not api_hash:
                print("Skipping invalid row (phone/api_id/api_hash required):", r)
                continue
            rows.append({'phone': phone.strip(), 'api_id': int(api_id), 'api_hash': api_hash.strip(), 'proxy': proxy.strip()})
    return rows

def append_output(row):
    file_exists = os.path.exists(OUTPUT_CSV)
    with open(OUTPUT_CSV, 'a', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=['phone', 'enc_session', 'created_at', 'error'])
        if not file_exists:
            writer.writeheader()
        writer.writerow(row)

def create_session_for(entry, fernet):
    phone = entry['phone']
    api_id = entry['api_id']
    api_hash = entry['api_hash']
    proxy = entry['proxy'] or None

    client = TelegramClient(StringSession(), api_id, api_hash,
                            proxy=None)  # For proxy support: set proxy param accordingly if needed
    try:
        print(f"\n--- Creating session for {phone} ---")
        # start() will ask for code via callback; we provide phone_number callback then prompt for code
        async def start_flow():
            await client.connect()
            if not await client.is_user_authorized():
                # request code will be sent; Telethon's start() also handles that, but we use send_code_request for clarity
                sent = await client.send_code_request(phone)
                print(f"Code sent to {phone}. Method: {sent.type if hasattr(sent,'type') else sent}")
                code = input(f"Enter the code for {phone}: ").strip()
                try:
                    # Some accounts may have 2FA enabled, .sign_in will raise if password required
                    await client.sign_in(phone=phone, code=code)
                except Exception as ex_sign:
                    # If password required (2FA)
                    if 'PASSWORD_HASH_INVALID' in str(ex_sign) or 'PASSWORD_GUESS_INVALID' in str(ex_sign) or 'SESSION_PASSWORD_NEEDED' in str(ex_sign) or 'Password' in str(ex_sign) or 'Two-step verification' in str(ex_sign):
                        pwd = getpass(f"Two-step password for {phone} (input hidden): ")
                        await client.sign_in(password=pwd)
                    else:
                        raise

            me = await client.get_me()
            print("Logged in as:", getattr(me, 'username', None) or getattr(me, 'first_name', None) or me.id)
            session_string = client.session.save()
            enc = fernet.encrypt(session_string.encode()).decode()
            return enc

        enc_session = client.loop.run_until_complete(start_flow())
        created_at = datetime.utcnow().isoformat()
        append_output({'phone': phone, 'enc_session': enc_session, 'created_at': created_at, 'error': ''})
        print(f"Saved encrypted session for {phone} at {created_at}")
    except Exception as e:
        print(f"Error creating session for {phone}: {e}")
        append_output({'phone': phone, 'enc_session': '', 'created_at': datetime.utcnow().isoformat(), 'error': str(e)})
    finally:
        try:
            client.loop.run_until_complete(client.disconnect())
        except Exception:
            pass

def main():
    ensure_input_csv()
    fernet = load_key()
    rows = read_phones()
    if not rows:
        print("No valid rows in phones.csv")
        return

    print("Will process", len(rows), "accounts. Press Ctrl+C to stop.")
    for i, entry in enumerate(rows, start=1):
        print(f"\n[{i}/{len(rows)}] Processing {entry['phone']}")
        create_session_for(entry, fernet)
        if i < len(rows):
            print(f"Sleeping {DELAY_BETWEEN} seconds before next account...")
            time.sleep(DELAY_BETWEEN)

if __name__ == "__main__":
    main()