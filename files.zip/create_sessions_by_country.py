#!/usr/bin/env python3
"""
create_sessions_by_country.py
Create/encrypt Telegram session strings (StringSession) for multiple user accounts,
with optional country grouping and proxy support.

Requirements:
  - Python 3.8+
  - pip install telethon cryptography pysocks

Usage examples:
  - Set encryption key:
      export TELE_SESSION_KEY="$(python -c 'from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())')"
  - Prepare phones.csv with header: phone,api_id,api_hash,country,proxy
  - Run for all:
      python create_sessions_by_country.py
  - Run only for USA:
      python create_sessions_by_country.py --country US
  - Process grouped by country with extra delay between countries:
      python create_sessions_by_country.py --group-by-country --delay-between-countries 60

CSV columns:
  phone (E.164 recommended), api_id, api_hash
  Optional: country (ISO code or name), proxy (protocol://host:port or protocol://user:pass@host:port)

Output:
  sessions.csv with columns: phone,enc_session,country,created_at,error

Security:
  - TELE_SESSION_KEY must be set (Fernet key). Keep it secret.
  - sessions.csv contains encrypted session strings; protect it.
"""
import argparse
import csv
import os
import sys
import time
from datetime import datetime
from getpass import getpass
from urllib.parse import urlparse

from cryptography.fernet import Fernet
from telethon import TelegramClient
from telethon.sessions import StringSession

# Defaults
INPUT_CSV = "phones.csv"
OUTPUT_CSV = "sessions.csv"

# CLI
parser = argparse.ArgumentParser(description="Create Telegram sessions from a CSV (with optional country/proxy).")
parser.add_argument("--input", "-i", default=INPUT_CSV, help="Input CSV file (default: phones.csv)")
parser.add_argument("--output", "-o", default=OUTPUT_CSV, help="Output CSV file (default: sessions.csv)")
parser.add_argument("--country", "-c", default=None, help="If set, process only rows matching this country value (case-insensitive)")
parser.add_argument("--group-by-country", action="store_true", help="Process accounts grouped by country (all of one country, then next)")
parser.add_argument("--delay", type=float, default=5.0, help="Seconds to wait between accounts (default: 5)")
parser.add_argument("--delay-between-countries", type=float, default=20.0, help="Seconds to wait between countries when grouping (default: 20)")
parser.add_argument("--dry-run", action="store_true", help="Don't actually sign in; just validate CSV and show counts")
args = parser.parse_args()

def load_key():
    key = os.getenv("TELE_SESSION_KEY")
    if not key:
        print("ERROR: TELE_SESSION_KEY environment variable not set.")
        print("Generate one with:\n"
              "  python -c \"from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())\"")
        sys.exit(1)
    try:
        return Fernet(key.encode())
    except Exception as e:
        print("ERROR: invalid TELE_SESSION_KEY:", e)
        sys.exit(1)

def parse_proxy(proxy_str):
    """
    Accepts:
      socks5://host:port
      socks5://user:pass@host:port
      http://host:port
    Returns Telethon-compatible proxy tuple or None.
    Telethon proxies often look like: ('socks5', 'host', port, True, 'user', 'pass')
    """
    if not proxy_str:
        return None
    try:
        p = urlparse(proxy_str)
        scheme = p.scheme.lower()
        host = p.hostname
        port = p.port
        username = p.username
        password = p.password
        if scheme.startswith('socks'):
            proxy_type = 'socks5' if '5' in scheme else 'socks4'
            # Telethon expects a tuple like: (proxy_type, addr, port, rdns, username, password)
            # rdns True is usually fine.
            if username:
                return (proxy_type, host, port, True, username, password)
            return (proxy_type, host, port, True)
        elif scheme in ('http', 'https'):
            # HTTP proxy: Telethon can use the same tuple style for HTTP proxis if PySocks supports it.
            if username:
                return ('http', host, port, True, username, password)
            return ('http', host, port, True)
        else:
            return None
    except Exception:
        return None

def ensure_input_csv(path):
    if not os.path.exists(path):
        print(f"ERROR: {path} not found. Create it with header: phone,api_id,api_hash,country,proxy")
        sys.exit(1)

def read_phones(path):
    rows = []
    with open(path, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for r in reader:
            phone = (r.get('phone') or r.get('phone_number') or '').strip()
            api_id = (r.get('api_id') or '').strip()
            api_hash = (r.get('api_hash') or '').strip()
            country = (r.get('country') or '').strip()
            proxy = (r.get('proxy') or '').strip()
            if not phone or not api_id or not api_hash:
                print("Skipping invalid row (phone/api_id/api_hash required):", r)
                continue
            try:
                api_id_int = int(api_id)
            except Exception:
                print("Skipping row with invalid api_id (must be integer):", r)
                continue
            rows.append({
                'phone': phone,
                'api_id': api_id_int,
                'api_hash': api_hash,
                'country': country,
                'proxy': proxy
            })
    return rows

def append_output(path, row):
    file_exists = os.path.exists(path)
    with open(path, 'a', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=['phone', 'enc_session', 'country', 'created_at', 'error'])
        if not file_exists:
            writer.writeheader()
        writer.writerow(row)

def create_session_for(entry, fernet, dry_run=False):
    phone = entry['phone']
    api_id = entry['api_id']
    api_hash = entry['api_hash']
    proxy_str = entry.get('proxy') or None
    proxy = parse_proxy(proxy_str)

    print(f"\n--- Creating session for {phone} (country: {entry.get('country') or 'N/A'}) ---")
    print("Proxy:", proxy_str or "none")
    if dry_run:
        print("Dry run mode: not contacting Telegram.")
        append_output(args.output, {'phone': phone, 'enc_session': '', 'country': entry.get('country',''), 'created_at': '', 'error': 'dry_run'})
        return

    client = TelegramClient(StringSession(), api_id, api_hash, proxy=proxy)
    try:
        async def start_flow():
            await client.connect()
            if not await client.is_user_authorized():
                sent = await client.send_code_request(phone)
                print(f"Code sent to {phone}. Method: {getattr(sent,'type',sent)}")
                code = input(f"Enter the code for {phone}: ").strip()
                try:
                    await client.sign_in(phone=phone, code=code)
                except Exception as ex_sign:
                    # handle 2FA (session password)
                    text = str(ex_sign)
                    if 'PASSWORD' in text.upper() or 'SESSION_PASSWORD_NEEDED' in text.upper() or 'two-step' in text.lower():
                        pwd = getpass(f"Two-step password for {phone} (input hidden): ")
                        await client.sign_in(password=pwd)
                    else:
                        raise

            me = await client.get_me()
            print("Logged in as:", getattr(me, 'username', None) or getattr(me, 'first_name', None) or me.id)
            session_string = client.session.save()
            enc = fernet.encrypt(session_string.encode()).decode()
            return enc

        enc_session = client.loop.run_until_complete(start_flow())
        created_at = datetime.utcnow().isoformat()
        append_output(args.output, {'phone': phone, 'enc_session': enc_session, 'country': entry.get('country',''), 'created_at': created_at, 'error': ''})
        print(f"Saved encrypted session for {phone} at {created_at}")
    except Exception as e:
        print(f"Error creating session for {phone}: {e}")
        append_output(args.output, {'phone': phone, 'enc_session': '', 'country': entry.get('country',''), 'created_at': datetime.utcnow().isoformat(), 'error': str(e)})
    finally:
        try:
            client.loop.run_until_complete(client.disconnect())
        except Exception:
            pass

def main():
    ensure_input_csv(args.input)
    fernet = load_key()
    rows = read_phones(args.input)
    if not rows:
        print("No valid rows in", args.input)
        return

    # Optionally filter by country
    if args.country:
        target = args.country.lower()
        rows = [r for r in rows if (r.get('country') or '').lower() == target]
        print(f"Filtered rows for country '{args.country}': {len(rows)}")

    if args.dry_run:
        # show counts per country
        per_country = {}
        for r in rows:
            c = r.get('country') or 'UNKNOWN'
            per_country[c] = per_country.get(c, 0) + 1
        print("Dry run: counts by country:")
        for c, n in per_country.items():
            print(f"  {c}: {n}")
        return

    if args.group_by_country:
        # group rows by country (stable order of countries)
        countries = {}
        order = []
        for r in rows:
            c = r.get('country') or 'UNKNOWN'
            if c not in countries:
                countries[c] = []
                order.append(c)
            countries[c].append(r)

        for idx, c in enumerate(order, start=1):
            print(f"\n=== Processing country {c} ({len(countries[c])} accounts) [{idx}/{len(order)}] ===")
            for i, entry in enumerate(countries[c], start=1):
                print(f"[{i}/{len(countries[c])}] {entry['phone']}")
                create_session_for(entry, fernet, dry_run=False)
                if i < len(countries[c]):
                    time.sleep(args.delay)
            if idx < len(order):
                print(f"Sleeping {args.delay_between_countries} seconds before next country...")
                time.sleep(args.delay_between_countries)
    else:
        # flat processing
        for i, entry in enumerate(rows, start=1):
            print(f"[{i}/{len(rows)}] {entry['phone']} (country: {entry.get('country') or 'N/A'})")
            create_session_for(entry, fernet, dry_run=False)
            if i < len(rows):
                time.sleep(args.delay)

if __name__ == "__main__":
    main()